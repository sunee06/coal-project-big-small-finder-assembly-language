.model small
.stack 100h
.data

msg1 db "Enter first number: $"
msg2 db 10,13,"Enter second number: $"
big1 db 10,13,"First number is larger$"
big2 db 10,13,"Second number is larger$"
equal db 10,13,"Both numbers are equal$"

num1 db ?
num2 db ?

.code
main proc

    mov ax, @data
    mov ds, ax

    ; ask for first number
    mov dx, offset msg1
    mov ah, 09h
    int 21h

    mov ah, 01h
    int 21h
    sub al, 48
    mov num1, al

    ; ask for second number
    mov dx, offset msg2
    mov ah, 09h
    int 21h

    mov ah, 01h
    int 21h
    sub al, 48
    mov num2, al

    ; compare numbers
    mov al, num1
    cmp al, num2

    je equal_case
    jg first_bigger
    jl second_bigger

equal_case:
    mov dx, offset equal
    mov ah, 09h
    int 21h
    jmp exit

first_bigger:
    mov dx, offset big1
    mov ah, 09h
    int 21h
    jmp exit

second_bigger:
    mov dx, offset big2
    mov ah, 09h
    int 21h

exit:
    mov ah, 4Ch
    int 21h

main endp
end main
